﻿namespace Winsonic_ModbusTCP
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnReset = new System.Windows.Forms.Button();
            this.txtInterval = new System.Windows.Forms.TextBox();
            this.btnStopTimer = new System.Windows.Forms.Button();
            this.btnReadByTimer = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.txtIPAddress = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReadIO = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnDI_7_Color = new System.Windows.Forms.Button();
            this.btnDI_6_Color = new System.Windows.Forms.Button();
            this.btnDI_5_Color = new System.Windows.Forms.Button();
            this.btnDI_4_Color = new System.Windows.Forms.Button();
            this.btnDI_3_Color = new System.Windows.Forms.Button();
            this.btnDI_2_Color = new System.Windows.Forms.Button();
            this.btnDI_1_Color = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.txtNoOfBit = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(674, 427);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnReset);
            this.tabPage1.Controls.Add(this.txtInterval);
            this.tabPage1.Controls.Add(this.btnStopTimer);
            this.tabPage1.Controls.Add(this.btnReadByTimer);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.txtResult);
            this.tabPage1.Controls.Add(this.txtNoOfBit);
            this.tabPage1.Controls.Add(this.txtPort);
            this.tabPage1.Controls.Add(this.txtIPAddress);
            this.tabPage1.Controls.Add(this.btnExit);
            this.tabPage1.Controls.Add(this.btnReadIO);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(666, 398);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "TCP_Modbus";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(155, 123);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 19;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // txtInterval
            // 
            this.txtInterval.Location = new System.Drawing.Point(393, 124);
            this.txtInterval.Name = "txtInterval";
            this.txtInterval.Size = new System.Drawing.Size(75, 22);
            this.txtInterval.TabIndex = 18;
            this.txtInterval.Text = "100";
            // 
            // btnStopTimer
            // 
            this.btnStopTimer.Location = new System.Drawing.Point(528, 23);
            this.btnStopTimer.Name = "btnStopTimer";
            this.btnStopTimer.Size = new System.Drawing.Size(114, 38);
            this.btnStopTimer.TabIndex = 16;
            this.btnStopTimer.Text = "StopTimer";
            this.btnStopTimer.UseVisualStyleBackColor = true;
            this.btnStopTimer.Click += new System.EventHandler(this.btnStopTimer_Click);
            // 
            // btnReadByTimer
            // 
            this.btnReadByTimer.Location = new System.Drawing.Point(393, 22);
            this.btnReadByTimer.Name = "btnReadByTimer";
            this.btnReadByTimer.Size = new System.Drawing.Size(129, 39);
            this.btnReadByTimer.TabIndex = 17;
            this.btnReadByTimer.Text = "ReadByTimer";
            this.btnReadByTimer.UseVisualStyleBackColor = true;
            this.btnReadByTimer.Click += new System.EventHandler(this.btnReadByTimer_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 25);
            this.label2.TabIndex = 11;
            this.label2.Text = "Result:  ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 25);
            this.label3.TabIndex = 12;
            this.label3.Text = "Port:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(490, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "ms";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(299, 124);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "Interval: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 25);
            this.label1.TabIndex = 15;
            this.label1.Text = "IP Address: ";
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(24, 155);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResult.Size = new System.Drawing.Size(618, 225);
            this.txtResult.TabIndex = 8;
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(86, 79);
            this.txtPort.Multiline = true;
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(48, 25);
            this.txtPort.TabIndex = 9;
            this.txtPort.Text = "502";
            // 
            // txtIPAddress
            // 
            this.txtIPAddress.Location = new System.Drawing.Point(155, 31);
            this.txtIPAddress.Multiline = true;
            this.txtIPAddress.Name = "txtIPAddress";
            this.txtIPAddress.Size = new System.Drawing.Size(217, 28);
            this.txtIPAddress.TabIndex = 10;
            this.txtIPAddress.Text = "192.168.11.70";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(574, 112);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(68, 37);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnReadIO
            // 
            this.btnReadIO.Location = new System.Drawing.Point(513, 74);
            this.btnReadIO.Name = "btnReadIO";
            this.btnReadIO.Size = new System.Drawing.Size(129, 38);
            this.btnReadIO.TabIndex = 7;
            this.btnReadIO.Text = "ReadIO";
            this.btnReadIO.UseVisualStyleBackColor = true;
            this.btnReadIO.Click += new System.EventHandler(this.btnReadIO_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.btnDI_7_Color);
            this.tabPage2.Controls.Add(this.btnDI_6_Color);
            this.tabPage2.Controls.Add(this.btnDI_5_Color);
            this.tabPage2.Controls.Add(this.btnDI_4_Color);
            this.tabPage2.Controls.Add(this.btnDI_3_Color);
            this.tabPage2.Controls.Add(this.btnDI_2_Color);
            this.tabPage2.Controls.Add(this.btnDI_1_Color);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(666, 399);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "IO";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(25, 225);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(27, 16);
            this.label13.TabIndex = 1;
            this.label13.Text = "DI7";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(25, 196);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 16);
            this.label12.TabIndex = 1;
            this.label12.Text = "DI6";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(25, 167);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 16);
            this.label11.TabIndex = 1;
            this.label11.Text = "DI5";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(25, 138);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(27, 16);
            this.label10.TabIndex = 1;
            this.label10.Text = "DI4";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(25, 109);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(27, 16);
            this.label9.TabIndex = 1;
            this.label9.Text = "DI3";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 80);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "DI2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "DI1";
            // 
            // btnDI_7_Color
            // 
            this.btnDI_7_Color.Location = new System.Drawing.Point(100, 222);
            this.btnDI_7_Color.Name = "btnDI_7_Color";
            this.btnDI_7_Color.Size = new System.Drawing.Size(75, 23);
            this.btnDI_7_Color.TabIndex = 0;
            this.btnDI_7_Color.UseVisualStyleBackColor = true;
            // 
            // btnDI_6_Color
            // 
            this.btnDI_6_Color.Location = new System.Drawing.Point(100, 193);
            this.btnDI_6_Color.Name = "btnDI_6_Color";
            this.btnDI_6_Color.Size = new System.Drawing.Size(75, 23);
            this.btnDI_6_Color.TabIndex = 0;
            this.btnDI_6_Color.UseVisualStyleBackColor = true;
            // 
            // btnDI_5_Color
            // 
            this.btnDI_5_Color.Location = new System.Drawing.Point(100, 164);
            this.btnDI_5_Color.Name = "btnDI_5_Color";
            this.btnDI_5_Color.Size = new System.Drawing.Size(75, 23);
            this.btnDI_5_Color.TabIndex = 0;
            this.btnDI_5_Color.UseVisualStyleBackColor = true;
            // 
            // btnDI_4_Color
            // 
            this.btnDI_4_Color.Location = new System.Drawing.Point(100, 135);
            this.btnDI_4_Color.Name = "btnDI_4_Color";
            this.btnDI_4_Color.Size = new System.Drawing.Size(75, 23);
            this.btnDI_4_Color.TabIndex = 0;
            this.btnDI_4_Color.UseVisualStyleBackColor = true;
            // 
            // btnDI_3_Color
            // 
            this.btnDI_3_Color.Location = new System.Drawing.Point(100, 106);
            this.btnDI_3_Color.Name = "btnDI_3_Color";
            this.btnDI_3_Color.Size = new System.Drawing.Size(75, 23);
            this.btnDI_3_Color.TabIndex = 0;
            this.btnDI_3_Color.UseVisualStyleBackColor = true;
            // 
            // btnDI_2_Color
            // 
            this.btnDI_2_Color.Location = new System.Drawing.Point(100, 77);
            this.btnDI_2_Color.Name = "btnDI_2_Color";
            this.btnDI_2_Color.Size = new System.Drawing.Size(75, 23);
            this.btnDI_2_Color.TabIndex = 0;
            this.btnDI_2_Color.UseVisualStyleBackColor = true;
            // 
            // btnDI_1_Color
            // 
            this.btnDI_1_Color.Location = new System.Drawing.Point(100, 48);
            this.btnDI_1_Color.Name = "btnDI_1_Color";
            this.btnDI_1_Color.Size = new System.Drawing.Size(75, 23);
            this.btnDI_1_Color.TabIndex = 0;
            this.btnDI_1_Color.UseVisualStyleBackColor = true;
            // 
            // timer2
            // 
            this.timer2.Interval = 60000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // txtNoOfBit
            // 
            this.txtNoOfBit.Location = new System.Drawing.Point(393, 79);
            this.txtNoOfBit.Multiline = true;
            this.txtNoOfBit.Name = "txtNoOfBit";
            this.txtNoOfBit.Size = new System.Drawing.Size(44, 25);
            this.txtNoOfBit.TabIndex = 9;
            this.txtNoOfBit.Text = "16";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(244, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "No discrete bit: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 467);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "TCP-IP";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtInterval;
        private System.Windows.Forms.Button btnStopTimer;
        private System.Windows.Forms.Button btnReadByTimer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.TextBox txtIPAddress;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReadIO;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnDI_6_Color;
        private System.Windows.Forms.Button btnDI_5_Color;
        private System.Windows.Forms.Button btnDI_4_Color;
        private System.Windows.Forms.Button btnDI_3_Color;
        private System.Windows.Forms.Button btnDI_2_Color;
        private System.Windows.Forms.Button btnDI_1_Color;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnDI_7_Color;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNoOfBit;
    }
}

