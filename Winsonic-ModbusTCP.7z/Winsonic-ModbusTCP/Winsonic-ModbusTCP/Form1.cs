﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Winsonic_ModbusTCP
{
    public partial class Form1 : Form
    {
        string ipAddress = string.Empty;
        static int port;
        TcpClient tcpClient;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ipAddress = txtIPAddress.Text.ToString();
            int.TryParse(txtPort.Text.ToString(), out port);
            //MessageBox.Show("port is parsed!");
            tcpClient = new TcpClient();
        }


        private void btnReadByTimer_Click(object sender, EventArgs e)
        {
            btnReadIO.Enabled = false;
            int.TryParse(txtInterval.Text.ToString(), out int a);
            timer1.Interval = a;
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                using (TcpClient tcpClient = new TcpClient())
                {
                    tcpClient.Connect(IPAddress.Parse(ipAddress), port);
                    NetworkStream stream = tcpClient.GetStream();
                    txtResult.AppendText($"Connected to {txtIPAddress.ToString()}");

                    // Read 8 Discrete Inputs (1x) starting from address 0x0014 (20)
                    byte[] readInputRequest = ModbusLibs.CreateModbusRequest(2, 0x02, 0x0100, 8);
                    stream.Write(readInputRequest, 0, readInputRequest.Length);
                    byte[] inputResponse = new byte[12]; // Response buffer
                    stream.Read(inputResponse, 0, inputResponse.Length);
                    txtResult.AppendText(BitConverter.ToString(inputResponse) + "\n");
                    txtResult.AppendText(Environment.NewLine);
                }

            }
            catch (Exception ex) { 
                timer1.Enabled=false;
                MessageBox.Show(ex.Message); }
        }


        private void btnStopTimer_Click(object sender, EventArgs e)
        {
            btnReadIO.Enabled = true;
            timer1.Enabled = false;
        }

        private void btnReadIO_Click(object sender, EventArgs e)
        {
            try
            {
                using (TcpClient tcpClient = new TcpClient())
                {
                    tcpClient.Connect(IPAddress.Parse(ipAddress), port);
                    NetworkStream stream = tcpClient.GetStream();
                    txtResult.AppendText($"Connected to {txtIPAddress.ToString()}");

                    // Read 8 Discrete Inputs (1x) starting from address 0x0014 (20)
                    byte[] readInputRequest = ModbusLibs.CreateModbusRequest(2, 0x02, 0x0100, 8);
                    stream.Write(readInputRequest, 0, readInputRequest.Length);
                    byte[] inputResponse = new byte[12]; // Response buffer
                    stream.Read(inputResponse, 0, inputResponse.Length);
                    txtResult.AppendText(BitConverter.ToString(inputResponse) + "\n");
                    txtResult.AppendText(Environment.NewLine);
                }

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (tcpClient != null) tcpClient.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (tcpClient != null) tcpClient.Close();
            this.Close();
        }
    }
}
