﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Winsonic_ModbusTCP
{
    public static class ModbusLibs
    {
        // Function to create Modbus TCP Read Request (Coils or Discrete Inputs)
        public static byte[] CreateModbusRequest(ushort transactionId, byte functionCode, ushort startAddress, ushort quantity)
        {
            byte[] request = new byte[12];
            request[0] = (byte)(transactionId >> 8); // Transaction ID High
            request[1] = (byte)(transactionId & 0xFF); // Transaction ID Low
            request[2] = 0x00; // Protocol ID High
            request[3] = 0x00; // Protocol ID Low
            request[4] = 0x00; // Length High
            request[5] = 0x06; // Length Low (6 remaining bytes)
            request[6] = 0x01; // Unit ID (Change if needed)
            request[7] = functionCode; // Function Code (0x01 = Coils, 0x02 = Discrete Inputs)
            request[8] = (byte)(startAddress >> 8); // Start Address High
            request[9] = (byte)(startAddress & 0xFF); // Start Address Low
            request[10] = (byte)(quantity >> 8); // Quantity High
            request[11] = (byte)(quantity & 0xFF); // Quantity Low
            return request;
        }

        // Function to create Modbus TCP Write Single Coil Request
        public static byte[] CreateWriteSingleCoilRequest(ushort transactionId, ushort coilAddress, bool value)
        {
            byte[] request = new byte[12];
            request[0] = (byte)(transactionId >> 8);
            request[1] = (byte)(transactionId & 0xFF);
            request[2] = 0x00; // Protocol ID
            request[3] = 0x00;
            request[4] = 0x00; // Length
            request[5] = 0x06;
            request[6] = 0x01; // Unit ID
            request[7] = 0x05; // Function Code (Write Single Coil)
            request[8] = (byte)(coilAddress >> 8);
            request[9] = (byte)(coilAddress & 0xFF);
            request[10] = value ? (byte)0xFF : (byte)0x00; // ON = 0xFF, OFF = 0x00
            request[11] = 0x00; // Always 0x00 for single coil write
            return request;
        }

        // Function to create Modbus TCP Write Multiple Coils Request
        public static byte[] CreateWriteMultipleCoilsRequest(ushort transactionId, ushort startAddress, bool[] values)
        {
            int byteCount = (values.Length + 7) / 8; // Calculate required bytes
            byte[] request = new byte[13 + byteCount];

            request[0] = (byte)(transactionId >> 8);
            request[1] = (byte)(transactionId & 0xFF);
            request[2] = 0x00; // Protocol ID
            request[3] = 0x00;
            request[4] = 0x00; // Length
            request[5] = (byte)(7 + byteCount); // Remaining bytes
            request[6] = 0x01; // Unit ID
            request[7] = 0x0F; // Function Code (Write Multiple Coils)
            request[8] = (byte)(startAddress >> 8);
            request[9] = (byte)(startAddress & 0xFF);
            request[10] = (byte)(values.Length >> 8); // Quantity High
            request[11] = (byte)(values.Length & 0xFF); // Quantity Low
            request[12] = (byte)byteCount; // Byte Count

            // Encode coil values into bytes
            for (int i = 0; i < values.Length; i++)
            {
                if (values[i])
                    request[13 + (i / 8)] |= (byte)(1 << (i % 8));
            }

            return request;
        }
    }
}
