﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Thread_20251215
{
    public partial class Form1 : Form
    {
        private Fx5uController _controller;
        private Fx5uScanService _scan;
        public Form1()
        {
            InitializeComponent();
            var modbus = new NModbusClient("192.168.1.10");
            _controller = new Fx5uController();
            _scan = new Fx5uScanService(modbus, _controller);

            _scan.Start();
        }

        private void uiTimer_Tick(object sender, EventArgs e)
        {
            lblX0.Text = _controller.Io.X0.ToString();
            lblD100.Text = _controller.Reg.D100.ToString();
            lblT0.Text = _controller.Timer.T0_Current.ToString();
        }

        private void btnY0_Click(object sender, EventArgs e)
        {
            _controller.SetY0(true);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }


}
