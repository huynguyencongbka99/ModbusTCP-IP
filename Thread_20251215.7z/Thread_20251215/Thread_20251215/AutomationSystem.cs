﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Threading;
using System.Net.Sockets;

using NModbus;

namespace Thread_20251215
{
    public class Fx5uIoState
    {
        // INPUT (X)
        public bool X0;
        public bool X1;
        public bool X2;

        // OUTPUT (Y)
        public bool Y0;
        public bool Y1;
        public bool Y2;

        // INTERNAL RELAY (M)
        public bool M100;
        public bool M101;

        public DateTime LastUpdate;
    }

    public class Fx5uRegisterState
    {
        public int D0;
        public int D1;
        public int D100;
        public int D200;

        public DateTime LastUpdate;
    }

    public class Fx5uTimerState
    {
        // Ví dụ: T0 current value map vào D500
        public int T0_Current;
        public bool T0_Done;

        public int T1_Current;
        public bool T1_Done;
    }

    public class Fx5uCounterState
    {
        public int C0_Current;
        public bool C0_Done;

        public int C1_Current;
        public bool C1_Done;
    }

    public interface IModbusClient
    {
        bool ReadCoil(ushort address);
        ushort ReadHoldingRegister(ushort address);

        Task WriteCoilAsync(ushort address, bool value);
        Task WriteHoldingRegisterAsync(ushort address, ushort value);
    }



    public class NModbusClient : IModbusClient
    {
        private readonly IModbusMaster _master;

        public NModbusClient(string ip, int port = 502)
        {
            var tcp = new TcpClient(ip, port);
            var factory = new ModbusFactory();
            _master = factory.CreateMaster(tcp);
        }

        public bool ReadCoil(ushort address)
        {
            return _master.ReadCoils(1, address, 1)[0];
        }

        public ushort ReadHoldingRegister(ushort address)
        {
            return _master.ReadHoldingRegisters(1, address, 1)[0];
        }

        public Task WriteCoilAsync(ushort address, bool value)
        {
            return Task.Run(() =>
                _master.WriteSingleCoil(1, address, value));
        }

        public Task WriteHoldingRegisterAsync(ushort address, ushort value)
        {
            return Task.Run(() =>
                _master.WriteSingleRegister(1, address, value));
        }
    }

    public class Fx5uController
    {
        public Fx5uIoState Io = new Fx5uIoState();
        public Fx5uRegisterState Reg = new Fx5uRegisterState();
        public Fx5uTimerState Timer  = new Fx5uTimerState();
        public Fx5uCounterState Counter  = new Fx5uCounterState();

        // API cho UI
        public void SetY0(bool value) => Io.Y0 = value;
        public void SetD100(int value) => Reg.D100 = value;

        // Logic mỗi scan
        public void ExecuteLogic()
        {
            // ví dụ logic
            if (Io.X0 && !Io.Y0)
                Io.Y0 = true;

            if (Counter.C0_Current > 100)
                Io.M100 = true;
        }
    }

    public class Fx5uScanService
    {
        private readonly IModbusClient _modbus;
        private readonly Fx5uController _controller;
        private CancellationTokenSource _cts;

        public Fx5uScanService(
            IModbusClient modbus,
            Fx5uController controller)
        {
            _modbus = modbus;
            _controller = controller;
        }

        public void Start()
        {
            _cts = new CancellationTokenSource();
            _ = Task.Run(() => ScanLoopAsync(_cts.Token));
        }

        public void Stop() => _cts.Cancel();

        private async Task ScanLoopAsync(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                ReadPlc();
                _controller.ExecuteLogic();
                await WritePlc();

                await Task.Delay(20, ct); // FX5U scan 20ms
            }
        }

        private void ReadPlc()
        {
            var io = _controller.Io;
            var reg = _controller.Reg;
            var t = _controller.Timer;
            var c = _controller.Counter;

            io.X0 = _modbus.ReadCoil(0);
            io.X1 = _modbus.ReadCoil(1);

            io.Y0 = _modbus.ReadCoil(10);

            reg.D0 = _modbus.ReadHoldingRegister(0);
            reg.D100 = _modbus.ReadHoldingRegister(100);

            t.T0_Current = _modbus.ReadHoldingRegister(500);
            t.T0_Done = _modbus.ReadCoil(200);

            c.C0_Current = _modbus.ReadHoldingRegister(600);
            c.C0_Done = _modbus.ReadCoil(210);
        }

        private async Task WritePlc()
        {
            var io = _controller.Io;
            var reg = _controller.Reg;

            await _modbus.WriteCoilAsync(10, io.Y0);
            await _modbus.WriteHoldingRegisterAsync(100, (ushort)reg.D100);
        }
    }






}
