﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NModbus;
using NModbus.Logging;
using System.Net.Sockets;
using System.Threading;



namespace H_TCP_IP_Test
{
    public partial class frmMain : Form
    {
        ModbusService modbus = new ModbusService();

        public frmMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            modbus.Start("192.168.1.11");
            lbConnectStatus.Text = "Connected to PLC";
            lbConnectStatus.ForeColor = Color.Lime;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Invoke(new Action(() =>
            {

                txtD0.Text = modbus.HoldingRegs[0].ToString();
                txtD10.Text = modbus.HoldingRegs[10].ToString();
                
            }));

            Invoke(new Action(() =>
            {
                for (int i = 0; i < 5; i++)
                {
                    string time1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ff");
                    txtLogs.AppendText($"{time1}, X{i} = {modbus.Inputs[i].ToString()}");
                    txtLogs.AppendText(Environment.NewLine);
                }
            }));

            Invoke(new Action(() =>
            {
                for (int i = 0; i < 5; i++)
                {
                    string time1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ff");
                    txtLogs.AppendText($"{time1}, Y{i} = {modbus.Coils[i].ToString()}");
                    txtLogs.AppendText(Environment.NewLine);
                }

            }));

        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            modbus.Stop();
        }
    }


    public class ModbusService
        {
            private TcpClient _tcpClient;
            private IModbusMaster _master;
            private Thread _pollThread;
            private bool _running;
            private readonly object _lock = new object();

            public ushort[] HoldingRegs { get; private set; } = new ushort[100];
        public bool[] Inputs { get; private set; } = new bool[100];
        public bool[] Coils { get; private set; } = new bool[100];

        public void Start(string ip, int port = 502)
            {
                _tcpClient = new TcpClient();
                _tcpClient.Connect(ip, port);

            // Tạo Modbus factory
            var factory = new ModbusFactory();

                // Tạo Modbus master
                _master = factory.CreateMaster(_tcpClient);

                // Set Timeout chuẩn Delta
                _master.Transport.ReadTimeout = 300;
                _master.Transport.WriteTimeout = 300;

                // Bắt đầu vòng đọc
                _running = true;
                _pollThread = new Thread(PollLoop) { IsBackground = true };
                _pollThread.Start();
            }

            private void PollLoop()
            {
                while (_running)
                {
                    try
                    {
                        lock (_lock)
                        {
                        // Đọc 30 thanh ghi Holding Register từ D0
                        // Nhớ rằng giá trị địa chỉ bắt đầu được gọi trong hàm là giá trị base ví dụ 404097 phải đổi thành 4096
                        ushort[] dataHoldings = _master.ReadHoldingRegisters(1, 4096, 30);
                        //ushort[] data = _master.ReadHoldingRegisters(0, 30);
                        Array.Copy(dataHoldings, HoldingRegs, dataHoldings.Length);

                        // Nhớ rằng giá trị địa chỉ bắt đầu được gọi trong hàm là giá trị base ví dụ 101025 phải đổi thành 1024
                        bool[] dataInputs = _master.ReadInputs(1, 1024, 30);
                        Array.Copy(dataInputs, Inputs, dataInputs.Length);

                        // Nhớ rằng giá trị địa chỉ bắt đầu được gọi trong hàm là giá trị base ví dụ 101281 phải đổi thành 1280
                        bool[] dataCoils = _master.ReadCoils(1, 1280, 30);
                        Array.Copy(dataCoils, Coils, dataCoils.Length);
                    }
                    }
                    catch
                    {
                        
                    }

                    Thread.Sleep(50); 
                }
            }

            public void WriteSingle(int address, ushort value)
            {
                lock (_lock)
                {
                    _master.WriteSingleRegister((byte)1, 4136, value);
                    // UnitID: 1 (hầu hết PLC Delta để mặc định 1)
                }
            }

            public void WriteMulti(int address, ushort[] values)
            {
                lock (_lock)
                {
                    _master.WriteMultipleRegisters((byte)1, 4136, values);
                }
            }

            public void Stop()
            {
                _running = false;
                try { _tcpClient?.Close(); } catch { }
            }
    }

}
